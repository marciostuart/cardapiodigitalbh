@php
    $venueTracking = isset($venue) ? ($venue->settings ?? []) : [];
@endphp
@if(!empty($venueTracking['google_analytics_id']))
    <script async src="https://www.googletagmanager.com/gtag/js?id={{ $venueTracking['google_analytics_id'] }}"></script><script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag('js',new Date());gtag('config','{{ $venueTracking['google_analytics_id'] }}');</script>
@endif
@if(!empty($venueTracking['meta_pixel_id']))
    <script>!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','{{ $venueTracking['meta_pixel_id'] }}');fbq('track','PageView');</script>
@endif
