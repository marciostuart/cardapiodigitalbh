<?php

namespace Tests\Feature;

use App\Models\DiningTable;
use App\Models\Tenant;
use App\Models\User;
use App\Models\Venue;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class OperationsDashboardTest extends TestCase
{
    use RefreshDatabase;

    public function test_a_venue_can_view_its_operations_dashboard(): void
    {
        $tenant = Tenant::create(['name' => 'Bistro Central', 'slug' => 'bistro-central']);
        $venue = Venue::create([
            'tenant_id' => $tenant->id,
            'name' => 'Bistro Central',
            'subdomain' => 'localhost',
        ]);
        DiningTable::create([
            'venue_id' => $venue->id,
            'code' => '12',
            'qr_token' => (string) str()->uuid(),
        ]);

        $user = User::factory()->create(['tenant_id' => $tenant->id, 'role' => 'owner']);

        $this->actingAs($user)->get('/operacao')
            ->assertOk()
            ->assertSee('Bistro Central')
            ->assertSee('Mesa 12')
            ->assertSee('Vendas de hoje');
    }
}
