<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tabs', function (Blueprint $table) {
            $table->string('customer_name', 80)->nullable()->after('code');
        });
    }

    public function down(): void
    {
        Schema::table('tabs', function (Blueprint $table) {
            $table->dropColumn('customer_name');
        });
    }
};
