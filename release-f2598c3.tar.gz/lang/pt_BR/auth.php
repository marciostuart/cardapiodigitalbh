<?php

return [
    'failed' => 'Estas credenciais não correspondem aos nossos registros.',
    'password' => 'A senha informada está incorreta.',
    'throttle' => 'Muitas tentativas. Tente novamente em :seconds segundos.',
];
