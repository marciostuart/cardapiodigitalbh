<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="refresh" content="0;url=/">
    <title>Cardápio Digital BH</title>
</head>
<body>
    <p>Redirecionando para o Cardápio Digital BH...</p>
</body>
</html>
