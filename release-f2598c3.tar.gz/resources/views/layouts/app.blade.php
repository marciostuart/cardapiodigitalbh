<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Laravel') }}</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        @vite(['resources/css/app.css', 'resources/js/app.js'])
        @include('layouts.tracking-head')
    </head>
    <body class="font-sans antialiased">
        @include('layouts.tracking-body')
        <div class="min-h-screen bg-gray-100">
            @include('layouts.navigation')

            @if(session()->has('impersonator_id'))
                <div class="bg-amber-300 px-4 py-3 text-center text-sm font-bold text-amber-950">
                    Modo suporte: você está acessando a conta de um cliente.
                    <form method="POST" action="{{ route('admin.leave') }}" class="ml-3 inline">@csrf<button class="underline">Retornar ao proprietário</button></form>
                </div>
            @endif

            <!-- Page Heading -->
            @isset($header)
                <header class="bg-white shadow">
                    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                        {{ $header }}
                    </div>
                </header>
            @endisset

            <!-- Page Content -->
            <main>
                {{ $slot }}
            </main>
        </div>
    </body>
</html>
